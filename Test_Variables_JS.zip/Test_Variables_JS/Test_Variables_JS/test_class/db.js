var mysql = require('mysql2');

var con = mysql.createConnection({
    host: "localhost",
    user: "user_MYSQL",
    password: "pass_MYSQL",
    database: "dbproduto"
});

con.connect(function(err){
    if(err) throw err;
    console.log("Conectado!");
    con.query("CREATE DATABASE dbproduto", function (err, result){
        if(err) throw err;
        console.log("Database criada!");
    });
    var sql = "CREATE TABLE IF NOT EXISTS produtos (Id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100), descricao VARCHAR(100), preco FLOAT(5), quantidade INT(5))";
    con.query(sql, function (err, result){
        if(err) throw err;
        console.log("Tabela criada!");
    });
    var sql = "INSERT INTO produtos (nome, descricao, preco, quantidade) VALUES ('arroz', 'saco', 7, 2), ('feijão', 'saco', 4, 4), ('refrigerante', 'lata', 8, 6), ('sabonete', 'barra', 2, 8);";
    con.query(sql, function (err, result){
        if(err) throw err;
        console.log("1 produto inserido");
    });
    con.query("SELECT * FROM produtos", function (err, result, fields){
        if(err) throw err;
        console.log(result);
    });
    var sql = "UPDATE produtos set nome='vinho', descricao='garrafa' where Id=3";
    con.query(sql, function (err, result){
        if(err) throw err;
        console.log("1 produto alterado");
    });
    var sql = "DELETE from produtos where Id=4";
    con.query(sql, function (err, result){
        if(err) throw err;
        console.log("1 produto excluído");
    });
});