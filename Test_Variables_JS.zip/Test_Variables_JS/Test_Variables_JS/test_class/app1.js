//var, let e const//
var greeter = "Hey hi";
var times = 4;
let greeting = "say Hi";
const cump = {
    message: "say GoodBy",
    times: 4 
}

if(times >=4){
    console.log(greeter);
}

if(true){
    let greeting = "say Hello instead";
    console.log(greeting);
}

console.log(greeting);
cump.message = "say By";
console.log(cump);

//try...catch//
try{
    try{
        throw new Error('Opa');
    }catch (ex){
        console.error('entrada', ex.message);
        throw ex;
    }finally{
        console.log('finalmente');
    }
}catch (ex){
    console.error('saida', ex.message);
}

//coleções//
const cars = [
    "Volvo",
    "BMW",
    "Mercedes",
    "McLaren"
];
cars[0] = "Ferrari";
console.log(cars.length);
console.log(cars.sort());
const vecs = new Set();
vecs.add("Golf");
vecs.add("Lamborghini");
vecs.add("Pegasus");
console.log(vecs.values());
const auts = new Map();
auts.set("CB500X", 500);
auts.set("Yamaha mt-07", 700);
auts.set("CB750X", 750);
auts.set("Yamaha mt-09", 900);
console.log(auts.size);
auts.delete("CB500X");
console.log(auts.size);

//funções, expressões e operadores//
var sum = function (  ) {
    var i, sum = 0;
    for (i = 0; i < arguments.length; i += 1) {
        sum += arguments[i];
    }
    return sum;
};

console.log(sum(4, 8, 15, 16, 23, 42));

//condicionais e repetições//
let read = require('readline-sync');
let i = 0;
num = read.question('Digite um valor: ');
if(num>=1){
    for(i=0;i<num;i++){
        i+= 1;
    }
    console.log("Valor maior que 1");
    console.log(num);
}else{
    switch(num){
        case 0:
            console.log("Valor menor que 1 ");
            break;
        default:
            console.log("Valor menor que 1 ");
    }
}